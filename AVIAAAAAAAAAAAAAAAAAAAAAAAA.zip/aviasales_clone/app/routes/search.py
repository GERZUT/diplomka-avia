from fastapi import APIRouter
from schemas.booking import BookingCreate
from services.flight_service import search_flights

router = APIRouter()

@router.get("/search")
def search(from_city: str, to_city: str, date: str):
    flights = search_flights(from_city, to_city, date)
    return flights
