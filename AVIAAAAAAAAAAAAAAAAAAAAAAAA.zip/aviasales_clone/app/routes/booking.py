from fastapi import APIRouter, Depends
from schemas.booking import BookingCreate, BookingResponse
from services.flight_service import search_flights

router = APIRouter()

@router.post("/book", response_model=BookingResponse)
def book_flight(booking: BookingCreate, db: Session = Depends(get_db)):
    db_booking = Booking(user_id=booking.user_id, flight_data=booking.flight_data)
    db.add(db_booking)
    db.commit()
    db.refresh(db_booking)
    return db_booking
