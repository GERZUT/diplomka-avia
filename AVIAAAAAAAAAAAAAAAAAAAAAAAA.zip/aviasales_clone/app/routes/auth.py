from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from services.user_service import create_user
from schemas.user import UserCreate, UserResponse
from dependencies.auth import verify_token
from core.logging import logger

router = APIRouter()

@router.post("/register", response_model=UserResponse)
def register_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = create_user(db, user.name, user.email, user.password)
    logger.info(f"User registered: {db_user.email}")
    return db_user
