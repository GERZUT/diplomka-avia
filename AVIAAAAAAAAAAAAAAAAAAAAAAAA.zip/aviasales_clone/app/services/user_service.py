from sqlalchemy.orm import Session
from models.user import User
import bcrypt
from core.logging import logger

def create_user(db: Session, name: str, email: str, password: str):
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    db_user = User(name=name, email=email, password_hash=hashed_password.decode('utf-8'))
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    logger.info(f"Created new user: {email}")
    return db_user
