import requests

def search_flights(from_city: str, to_city: str, date: str):
    # Mock external API integration
    response = requests.get(f"https://api.example.com/search?from={from_city}&to={to_city}&date={date}")
    return response.json()
