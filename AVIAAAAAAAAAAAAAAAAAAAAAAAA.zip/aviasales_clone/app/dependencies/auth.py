from fastapi import Depends, HTTPException
from jwt import decode, PyJWTError
from sqlalchemy.orm import Session
from models.user import User
from core.config import settings

def verify_token(token: str, db: Session):
    try:
        payload = decode(token, settings.secret_key, algorithms=[settings.jwt_algorithm])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = db.query(User).filter(User.email == email).first()
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        return user
    except PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
