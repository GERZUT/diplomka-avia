from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_search_flights():
    response = client.get("/search?from_city=New York&to_city=Los Angeles&date=2025-05-01")
    assert response.status_code == 200
    assert "flights" in response.json()
