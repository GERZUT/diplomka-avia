# tests/test_auth.py
from fastapi.testclient import TestClient
from main import app
from models import User
from sqlalchemy.orm import Session

client = TestClient(app)


def test_login(db: Session):

    user = User(email="john@example.com", password_hash="hashed_password")
    db.add(user)
    db.commit()


    response = client.post("/login", data={"email": "john@example.com", "password": "password"})

    assert response.status_code == 200
    assert "access_token" in response.json()


def test_login_invalid_credentials(db: Session):
    response = client.post("/login", data={"email": "wrong@example.com", "password": "wrongpassword"})
    assert response.status_code == 401
