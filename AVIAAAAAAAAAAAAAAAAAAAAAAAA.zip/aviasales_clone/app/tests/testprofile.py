from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_get_profile():
    token = "valid_jwt_token"
    response = client.get("/profile", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.json() == {"email": "john@example.com", "name": "John"}
