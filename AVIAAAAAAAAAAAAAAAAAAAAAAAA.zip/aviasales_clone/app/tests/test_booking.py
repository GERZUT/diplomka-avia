from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_book_ticket():
    response = client.post("/book", json={"flight_id": 123, "user_id": 1, "seat_count": 1})
    assert response.status_code == 200
    assert response.json() == {"message": "Booking confirmed"}  # Проверяем, что получен успешный ответ
