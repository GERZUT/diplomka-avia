from pydantic import BaseModel
from datetime import datetime

class BookingCreate(BaseModel):
    user_id: int
    flight_data: str

class BookingResponse(BaseModel):
    id: int
    user_id: int
    flight_data: str
    booking_date: datetime

    class Config:
        orm_mode = True
