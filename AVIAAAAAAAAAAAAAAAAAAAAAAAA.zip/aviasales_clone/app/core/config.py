import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    secret_key: str = os.getenv("SECRET_KEY", "mysecretkey")
    database_url: str = os.getenv("DATABASE_URL", "postgresql://user:password@localhost/aviasales")
    jwt_algorithm: str = "HS256"
    jwt_expiration_minutes: int = 60

    class Config:
        env_file = ".env"

settings = Settings()

